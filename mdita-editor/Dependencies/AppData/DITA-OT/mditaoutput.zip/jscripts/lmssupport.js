    function SubmitAnswers(){
        var correctCount = 0;
        var totalQuestions = test.Questions.length;
        
        var resultsSummary = "";
        
        for (var i in test.Questions){
            var question = test.Questions[i];
            
            var wasCorrect = false;
            var correctAnswer = null;
            var learnerResponse = "N/A";
            
            switch (question.Type){
                case QUESTION_TYPE_CHOICE:
                    correctAnswer = parseInt(1013-parseInt(question.CorrectAnswer.substring(question.CorrectAnswer.length-4))+parseInt(i));
                    for (var answerIndex = 0; answerIndex < question.Answers.length-1; answerIndex++){
                        var elID = (parseInt(i)+1)+'' + "_RESP_MC" + answerIndex +'';
                        if (document.getElementById(elID).checked == true){
                            learnerResponse = answerIndex;
                        }
                    }
  
                break;
                
                default:
                    alert("invalid question type detected");
                break;
            }
            
            wasCorrect = (correctAnswer == learnerResponse);
            if (wasCorrect) {correctCount++;}
            
//            if (parent.RecordQuestion){
//                parent.RecordQuestion(test.Questions[i].Id, 
//                                        test.Questions[i].Text, 
//                                        test.Questions[i].Type, 
//                                        learnerResponse, 
//                                        correctAnswer, 
//                                        wasCorrect, 
//                                        test.Questions[i].ObjectiveId);
//            }
            
            resultsSummary += "<div class='questionResult'><h3>Question " + (parseInt(i)+1) + "</h3>";
            resultsSummary += "<b>"+ question.Text + "</b><br><br>";
                    for (var answerIndex = 0; answerIndex < question.Answers.length-1; answerIndex++){
                         if (correctAnswer == answerIndex) resultsSummary +="<b>";
			 resultsSummary += answerIndex + ". "+ question.Answers[answerIndex] + "<br>";
                         if (correctAnswer == answerIndex) resultsSummary +="</b>";
                    }
            if (wasCorrect) {
                resultsSummary += "Your answer: " + learnerResponse + " - <em>Correct</em><br>"
            }
            else{
                resultsSummary += "Your answer: " + learnerResponse + " - <em>Incorrect</em><br>"
                resultsSummary += "Correct answer: " + correctAnswer + "<br>"
            }
            resultsSummary += "</div>";
        }
        var scoreScale = correctCount / totalQuestions;
        var score = Math.round(scoreScale * 100);
        resultsSummary = "<h3>Score: " + score + " (Correct Answers:"+correctCount+"/"+(parseInt(i)+1)+") </h3>" + resultsSummary;
        day = new Date();
        id = day.getTime();
        eval("newpage = window.open('', '" + id + "', 'toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=1,width=800,height=600');");
        newpage.document.write ("<div id='test'></div>");
        newpage.document.getElementById("test").innerHTML = resultsSummary;
        
//        doSetValue( "cmi.score.scaled", scoreScale );
//        doSetValue( "cmi.score.raw", correctCount );
//        doSetValue( "cmi.completion_status", "completed" );
//        doSetValue( "cmi.exit", "" );

        //  Indicate that the SCO was finished normally
// //        exitPageStatus = true;
//        var result = doTerminate();
    }
