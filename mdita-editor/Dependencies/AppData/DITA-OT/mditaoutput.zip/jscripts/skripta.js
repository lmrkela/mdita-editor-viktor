var contentSizes = ['40%', '50%', '60%', '70%', '80%', '90%'];
var fontSizes = ['9px', '12px', '15px', '18px', '22px', '24px'];
var curentFontSize = 2;
var curentContentSize = 5;

function lightTheme(){
	$("body").css("background-image", "url('./css/bg-light.png')");
	$("body").css("color", "#000000");
	$("img").css("border", "1px solid #e3e3e3");
	$("img").css("background", "#fff");
	$(".darkButton").css("background-image", "url('./css/dark-off.png')");
	$(".lightButton").css("background-image", "url('./css/light-on.png')");
	$(".settingsButton").css("background-image", "url('./css/settings-light.png')");
	$(".linija").css("background", "url('./css/divider-light.png') no-repeat center")
}

function darkTheme(){
	$("body").css("background-image", "url('./css/bg-dark.png')");
	$("body").css("color", "#d6d9dc");
	$("img").css("border", "1px solid #3c4349");
	$("img").css("background", "#171a1c");
	$(".darkButton").css("background-image", "url('./css/dark-on.png')");
	$(".lightButton").css("background-image", "url('./css/light-off.png')");
	$(".settingsButton").css("background-image", "url('./css/settings-dark.png')");
	$(".linija").css("background", "url('./css/divider-dark.png') no-repeat center")
}

function defaultSetting(){
	$("body").css("font-size", fontSizes[curentFontSize]);
	$(".nested0").css("width", contentSizes[5]);
	openSans();
	lightTheme();
	//$("body").insertBefore(settingsDiv);
}

function openSans(){
	$("body").css("font-family", "'Open Sans', sans-serif");
	$(".sansButton").css("background-image", "url('./css/sans-on.png')");
	$(".serifButton").css("background-image", "url('./css/serif-off.png')");
}

function PTSerif(){
	$("body").css("font-family", "'PT Serif', serif");
	$(".sansButton").css("background-image", "url('./css/sans-off.png')");
	$(".serifButton").css("background-image", "url('./css/serif-on.png')");
}

function fontSizeUp(){
	if(curentFontSize < 5) {
		curentFontSize++;
		$("body").css("font-size", fontSizes[curentFontSize]);
		$(".minusTextButton").css("background-image", "url('./css/minus-on.png')");
	}
	if(curentFontSize == 5) {
		$(".plusTextButton").css("background-image", "url('./css/plus-off.png')");
	}
}

function fontSizeDown(){
	if(curentFontSize > 0) {
		curentFontSize--;
		$("body").css("font-size", fontSizes[curentFontSize]);
		$(".plusTextButton").css("background-image", "url('./css/plus-on.png')");
	}
	if(curentFontSize == 0) {
		$(".minusTextButton").css("background-image", "url('./css/minus-off.png')");
	}
}

function contentSizeUp(){
	if(curentContentSize < 5) {
		curentContentSize++;
		$(".nested0").css("width", contentSizes[curentContentSize]);
		$(".minusContentButton").css("background-image", "url('./css/minus-on.png')");
	}
	if(curentContentSize == 5) {
		$(".plusContentButton").css("background-image", "url('./css/plus-off.png')");
	}
}

function contentSizeDown(){
	if(curentContentSize > 0) {
		curentContentSize--;
		$(".nested0").css("width", contentSizes[curentContentSize]);
		$(".plusContentButton").css("background-image", "url('./css/plus-on.png')");
	}
	if(curentContentSize == 0) {
		$(".minusContentButton").css("background-image", "url('./css/minus-off.png')");
	}
}

$(function(){
	$(".darkButton").click(function() {
		darkTheme();
	});

	$(".lightButton").click(function() {
		lightTheme();
	});

	$(".sansButton").click(function() {
		openSans();
	});

	$(".serifButton").click(function() {
		PTSerif();
	});

	$(".settingsButton").click(function() {
		$(".popup").toggle();
	});

	$(".plusTextButton").click(function() {
		fontSizeUp();
	});

	$(".minusTextButton").click(function() {
		fontSizeDown();
	});

	$(".plusContentButton").click(function() {
		contentSizeUp();
	});

	$(".minusContentButton").click(function() {
		contentSizeDown();
	});

	defaultSetting();
});

//usr/share/jboss/server/default/deploy/lams/lams.war/css

