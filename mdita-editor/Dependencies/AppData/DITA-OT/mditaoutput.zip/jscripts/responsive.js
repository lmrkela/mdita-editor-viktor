$(document).ready(function(){
	// DODATAK ZA RESPONSIVE 	

  function galleyResize(){
    galleryHeight = windowHeight * 0.4;
    $('.slides').attr('style', 'height: ' + galleryHeight + 'px !important');
  }

 function setHeight() {
  windowHeight = $(window).innerHeight();
  $('.slidesjs-container').css('height', windowHeight - 150);        
  $('.section.wrapper_section_01').css('height', windowHeight - 150);    
};

if($(window).width() <= 992){
    setHeight();     
}

if($(window).width() <= 768){
    galleyResize();
}

   $(window).resize(function() {
    if($(window).width() <= 992){
      setHeight();        
    } else if($(window).width() <= 768){
      galleyResize();
    } else {
      $('.slidesjs-container').css('height', 624);
      $('.section.wrapper_section_01').css('height', 624);
      $('.slides').css('height', 490);
    }
  });

// DODATAK ZA RESPONSIVE

// function touchHandler(event) {
//     var touch = event.changedTouches[0];

//     var simulatedEvent = document.createEvent("MouseEvent");
//     simulatedEvent.initMouseEvent({
//       touchstart: "mousedown",
//       touchmove: "mousemove",
//       touchend: "mouseup"
//     }[event.type], true, true, window, 1,
//     touch.screenX, touch.screenY,
//     touch.clientX, touch.clientY, false,
//     false, false, false, 0, null);

//     touch.target.dispatchEvent(simulatedEvent);
//     event.preventDefault();
//   }

//   function init() {
//     document.addEventListener("touchstart", touchHandler, true);
//     document.addEventListener("touchmove", touchHandler, true);
//     document.addEventListener("touchend", touchHandler, true);
//     document.addEventListener("touchcancel", touchHandler, true);
//   }
  
});

